export default {
    primary: "#DD1219",
    white: "#fff",
    lightWhite: "#f2eef2",
    black: "black",
    darkGrey2: '#2D2D2D',
    newInputFieldBorder: '#DEDEDE',
    grey: "#d5d5d5",
    twoButtons: '#F5F5F5',
    blue: '#3A82FF',
    darkGrey: '#707070',
    inputFieldBorder: "#393939",
    inputFieldBackgroundColor: "#efefef",
    inputFieldPlaceholder: "#9AA3AE",
    lightBlue: '#C0FAEB',
    useNameScreenTopView: '#d218a7'
};
